#!/bin/bash
#This script needs to be edited for each run.
#Define PDB Filename & GROMACS Pameters
NAME=$1
FORCEFIELD="chramm36"
WATERMODEL="tip3p"
WATERTOPFILE="spc216.gro"
BOXTYPE="dodecahedron"
BOXORIENTATION="1.0"
BOXSIZE="5.0"
BOXCENTER="2.5"
#source  /opt/gromacs-5.1.4/gcc/cuda/bin/GMXRC
#gromacs 安装路径
source /opt/gromacs-5.1.4/gcc/mpi_cuda/bin/GMXRC 
# generate GROMACS .gro file
echo 1 | gmx_mpi pdb2gmx -f ${NAME}.pdb -o ${NAME}.gro -water ${WATERMODEL} -ignh -p topol.top
# define the box
gmx_mpi editconf -f ${NAME}.gro -o ${NAME}_box.gro -bt ${BOXTYPE} -c -d ${BOXORIENTATION}
# energy minimization of the structure in vacuum
gmx_mpi grompp -f minim.mdp -c ${NAME}_box.gro -p topol.top -o em-vacuum.tpr
mpirun -np 8 gmx_mpi mdrun -ntomp 9 -gpu_id 00112233 -v -deffnm em-vacuum
# add solvate
gmx_mpi solvate -cp em-vacuum.gro -cs ${WATERTOPFILE} -o ${NAME}_solv.gro -p topol.top
# add icons
gmx_mpi grompp -f ions.mdp -c ${NAME}_solv.gro -p topol.top -o ions.tpr
echo SOL | gmx_mpi genion -s ions.tpr -o ${NAME}_solv_ions.gro -p topol.top -pname NA -nname CL -conc 0.1 -neutral
# energy minimization of the structure in solvate
gmx_mpi grompp -f minim.mdp -c ${NAME}_solv_ions.gro -p topol.top -o em.tpr
mpirun -np 8 gmx_mpi mdrun -ntomp 9 -gpu_id 00112233 -v -deffnm em
# nvt
gmx_mpi grompp -f nvt.mdp -c em.gro -p topol.top -o nvt.tpr
mpirun -np 8 gmx_mpi mdrun -ntomp 9 -gpu_id 00112233 -v -deffnm nvt
# npt
gmx_mpi grompp -f npt.mdp -c nvt.gro -t nvt.cpt -p topol.top -o npt.tpr
mpirun -np 8 gmx_mpi mdrun -ntomp 9 -gpu_id 00112233 -v -deffnm npt
# md
gmx_mpi grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -o md.tpr
