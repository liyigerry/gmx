#coding=utf-8
from util import *
import mdtraj as md
import argparse
from pylab import *



def rmsd(traj_file,pdb1,pdb2,fig_name='RMSD',label1 = 'pdb1',label2='pdb2'):
	# traj = load_traj([traj_file],pdb1)
	traj_iter = md.iterload(traj_file, top=pdb1,chunk=100)
	try:
		traj = traj_iter.next()
	except:
		traj = next(traj_iter)
	for t in traj_iter:
	    traj += t
	top1 = md.load(pdb1)
	rmsd_to_top1 = md.rmsd(traj, top1, atom_indices=top1.topology.select('backbone'),parallel=True)
	top2 = md.load(pdb2)
	rmsd_to_top2 = md.rmsd(traj, top2, atom_indices=top2.topology.select('backbone'),parallel=True)
	figure(figsize=(8,6))
	plot(rmsd_to_top1, label=label1)
	plot(rmsd_to_top2,  label=label2)
	xlabel('Time (ns)',fontsize=14)
	xticks(range(0,len(traj)+1,5000)[:-1]+[len(traj)],range(0,len(traj)/100+1,50)[:-1]+[round(len(traj)/100.0,5)],fontsize=12)
	# xticks(range(0,len(traj),5000)[:-1]+[len(traj)],range(0,len(traj)/100+1,50)[:-1]+[round(len(traj)/100.0,5)],fontsize=12)
	ylabel(r'backbone RMSD (nm)',fontsize=14)
	yticks(fontsize=12)
	xlim(0,len(traj))
	legend(fontsize=12)
	savefig('{}.png'.format(fig_name),dpi=720,bbox_inches='tight')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-xtc",help = '轨迹文件')
    parser.add_argument("-pdb1")
    parser.add_argument("-pdb2")
    parser.add_argument("-fig",default='RMSD',help = '图片名称')
    parser.add_argument("-label1",default='pdb1',help = '图例1')
    parser.add_argument("-label2",default='pdb2',help = '图例2')
    args = parser.parse_args()	

    rmsd(args.xtc,args.pdb1,args.pdb2,args.fig,args.label1,args.label2)