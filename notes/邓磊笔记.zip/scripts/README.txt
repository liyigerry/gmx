﻿该脚本目录包含FEL.py、RMSD.py、correlation.py等python脚本，这些脚本有相互引用关系，不熟练python的话，请不要复制单个脚本到别处运行，将该目录整体复制即可，其中：
FEL.py 脚本主要用于制作自由能图谱及提取对应的代表性结构，可制作调和元动力学模拟的自由能图谱、或以PCA以及其他特征数据（RMSD、二面角等）采用概率密度函数制作的自由能图谱，可以制作一维自由能轮廓，二维自由能平面，三维立体显示的自由能图谱
RMSD用于计算RMSD值
correlation 用于计算模拟轨迹中两两残基的运动相关性并生成图片
ps:脚本采用python3.6编写，python2.7或其他版本不保证完全兼容

所有脚本均可用命令行的方式直接运行（需自行配置相关的python环境），下面分别介绍各脚本的运行方法：

FEL.py:
可使用python FEL.py -h 显示帮助信息

            usage: FEL.py [-h] [-xtc XTC [XTC ...]] [-pdb PDB]
                          [-pdf | -fes | -FEL_3d | -pca] [-data DATA] [-data1 DATA1]
                          [-fig FIG] [-kbt KBT] [-xy XY [XY ...]] [-area AREA [AREA ...]]
                          [-n N] [-step STEP] [-unit UNIT] [-hills HILLS]

            optional arguments:
              -h, --help            show this help message and exit
              -xtc XTC [XTC ...]    使用pca制作自由能时，需指定xtc格式的轨迹文件以及pdb文件
              -pdb PDB
              -pdf                  使用概率密度函数制作自由能图谱
              -fes                  使用plumed sum_hills 重构的自由能数据画出自由能图谱(2D显示)
              -FEL_3d               3D显示二维自由能图谱
              -pca                  使用pca的前两个向量制作自由能
              -data DATA            使用概率密度函数的制作自由能时，该参数输入第一个数据，plumd重构的自由能，用该参数指定自由能所在的文件
              -data1 DATA1          使用概率密度函数制作自由能时，只指定data1时制作一维自由能，同时指定data2则制作二维自由能
              -fig FIG              自由能图谱的保存路径及名称，e.t. \test\fig
              -kbt KBT              玻尔兹曼常数，默认2.479
              -xy XY [XY ...]       xy轴名称，e.t. "x y"
              -area AREA [AREA ...]
                                    提取代表性结构的自由能有区域，按照x1 x2 y1 y2为一个区域，多个区域按同样规则放在后面，使用元动力学重构的自由能提取结构时，需同时制定HILLS文件
              -n N                  每个自由能区域提取几个结构，默认提取一个
              -step STEP            用于制作自由能的数据是间隔多少步输出一次的
              -unit UNIT            模拟轨迹步长时间(单位ps)
              -hills HILLS          HILLS文件(plumed模拟输出的文件，详见我的实验记录)
用法示例：
1、用plumed执行的调和元动力学模拟重构的自由能制作图谱（重构自由能的方法见我实验笔记部分）
    1.1制作自由能图谱：
        python FEL.py -fes -FEL_3d -xy cv1 cv2 -fig WTE-FEL -data fes.dat
        fes.dat为plumed重构的自由能数据文件
        该命令执行完会生成WTE-FEL.png的二维自由能平面，以及WTE-FEL.html的三维自由能文件，该文件为网页文件，浏览器打开可显示三维图像，自行调整合适角度大小保存图片即可
       1.2 提取只有能图谱中的代表性结构
           首先根据前面步骤得到的自由能图谱中确定从哪些区域提取代表性结构，确定一个 大概范围的 矩形框，分别得到矩形框的四个坐标，x1,x2,y1,y2(矩形框对应到x轴y轴的范围)
           python FEL.py -fes -xy cv1 cv2 -fig WTE-FEL -area x11 x12 y11 y12 x21 x22 y21 y22(注意只能用空格隔开，多个区域在后面接着按该格式添加即可) -n 5 -unit 0.002 -step 500 -hills HILLs
           该命令会输出输出一系列的数值，如下：
               0: 3840,3728,3300,367,3278
            1: 12466,12439,9375,9309,11664
            2: 319794,319683,236540,306742,319713
            3: 433689,433704,285504,434466,433361
            4: 397393,123566,396773,396955,123567
            5: 70463,167269,70765,169288,169312
        表示我选了五个区域，0-5是输出编号，不重要，每个编号后面五个数值，对用上述命令中-n 5,表示每个区域我提取五个代表性结构（可筛选最好的结构），每个数字是一个模拟轨迹中的时间点,使用gmx工具从轨迹中提取即可：
        gmx trjconv -f md.trr -s md.tpr -o 3840.pdb -pbc mol -ur compact -b 3840 -e 3840 （以上述输出中的第0条第一个为例）



2、以PCA的前两个向量制作自由能图谱
    2.1 只有能图谱：
        以pca制作自由能时需提供轨迹及相应的pdb文件进行pca分析(轨迹需xtc格式),PCA制作的自由能还是采用的概率密度函数制作，所以也需要玻尔兹曼常数
        python FEL.py -pca -FEL_3d -xtc md.xtc -pdb md.pdb -xy pc1 pc2 -fig PCA-FEL -kbt 2.479
        该输出与1.1类似
    2.2 提取代表性结构
        与1.2类似
        python FEL.py -pca -xy cv1 cv2 -fig PCA-FEL -area x11 x12 y11 y12 x21 x22 y21 y22(注意只能用空格隔开，多个区域在后面接着按该格式添加即可) -n 5 -unit 0.002 -step 5000(我这模拟轨迹是每5000步输出一次)
        输出结构也与上述类似



3、其他数据采用概率密度函数制作自由能图谱
    3.1 自由能图谱
        该方式可制作一维自由能图谱或二维自由能图谱，一维自由能图谱采用-data ***输入一个数据文件即可，二维自由能图谱需加上 -data1 *** 输入第二个数据文件，该数据文件可以是RMSD文件（rmsd.xvg）、模拟过程中两个原子或原子团的距离变化等等（请自行找相关输出方法，距离、rmsd、二面角等可用plumed进行输出，设置相关参数即可，本身简单但描述太复杂，具体见plumed文档及相应的教程），脚本将采用文件中最后一列数据制作自由能。注：xvg文件或其他文件请删除#开头的注释或@开头的无关信息，只保留多列的数据即可，否则可能读取文件失败

        python FEL.py -pdf -FEL_3d -data RMSD.xvg -data1 distance.dat -xy rmsd distance -fig pdf-FEL 
    3.2 提取代表性结构
        python FEL.py -pdf -data RMSD.xvg -data1 distance.dat -xy rmsd distance -fig pdf-FEL -area x11 x12 y11 y12 x21 x22 y21 y22(注意只能用空格隔开，多个区域在后面接着按该格式添加即可) -n 5 -unit 0.002 -step 5000(我这模拟轨迹是每5000步输出一次)


correlation.py: 用于计算普通分子动力学轨迹两两残基的运动相关性
        
        python correlation.py -h


        usage: correlation.py [-h] [-xtc XTC [XTC ...]] [-pdb PDB] [-figname FIGNAME]
                              [-save SAVE]

        optional arguments:
          -h, --help          show this help message and exit
          -xtc XTC [XTC ...]  轨迹文件,可使用通配符模式*.xtc，或多个轨迹文件用空格隔开
          -pdb PDB            pdb文件
          -figname FIGNAME    图片名称,默认correlation
          -save SAVE          是否保存correlation，是则输入文件名字，默认不保存
该脚本使用较为简单,按照帮助信息输入对应文件即可

contactmap.py、RMSD.py主要针对我的实验，contactmap.py用于构建contactmap CVs、RMSD.py相对于unliganded与liganded制作RMSD，一般应该用不到，普通的rmsd可用gmx工具生成即可，这两个脚本可用于会python的同学参考
脚本使用同样较为简单，使用python  contactmap.py -h 显示帮助信息，按照帮助信息输入对应文件即可