#coding=utf-8

import os,sys
import  argparse
from glob import glob

from base_func import *


def correlation(trajs,top,fig_name='correlation',save_ = ''):
    network = Network(trajs,top,auto_build=False)
    network.load_traj()
    network.correlation_analysis()

    correlation_result = network.correlation #相关性矩阵
    if save_:
        network.save_correlation('{}.dat'.format(save_))

    fig = plot_correlation(correlation_result) #该函数定义在base_fun.py中
    fig.savefig('{}.png'.format(fig_name))
    print('#'*40)
    print('correlation saved to {}.png!'.format(fig_name))
    print('#'*40)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-xtc",nargs='+',help = '轨迹文件,可使用通配符模式*.xtc，或多个轨迹文件用空格隔开')
    parser.add_argument("-pdb",help = 'pdb文件')
    parser.add_argument("-figname",default='correlation',help = '图片名称,默认correlation')
    parser.add_argument("-save",default='',help = '是否保存correlation，是则输入文件名字，默认不保存')
    args = parser.parse_args()
    xtc = []
    for x in args.xtc:
    	if '*' in x:
    		xtc += glob(x)
    	else:
    		xtc.append(x)


    correlation(xtc,args.pdb,args.figname,args.save)

