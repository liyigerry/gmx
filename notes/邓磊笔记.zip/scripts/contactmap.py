import mdtraj as md
import itertools
import re
import os ,sys
import numpy as np
import  argparse

from base_func import DataLoad

def get_atom_pairs(correlation_data1,correlation_data2,pdb):
    correlation1 = DataLoad(correlation_data1)
    correlation2 = DataLoad(correlation_data2)

    correlation = np.zeros(correlation1.shape)
    correlation_diff = np.zeros(correlation1.shape)
    for i in range(correlation1.shape[0]):
        for j in range(i,correlation1.shape[0]):
            correlation[i][j] = correlation1[i][j]
            correlation[j][i] = correlation2[j][i]
            m =  correlation1[i][j]-correlation2[j][i]
            if m > 0.4 or m < -0.4:
                correlation_diff[i][j] = m
            
                correlation_diff[j][i] = m

    resid = np.where(np.abs(correlation_diff) > 0.9)

    top = md.load(pdb)
    index1 = []
    for i in resid[0]:
        index1.append(top.topology.select('resid {} and name CA'.format(i)))
    index1 = np.array(index1)
    index2 = []
    for i in resid[1]:
        index2.append(top.topology.select('resid {} and name CA'.format(i)))
    index2 = np.array(index2)

    pair = np.array([index1,index2]).T[0]
    return pair
def compute_pairs_distance(pairs,pdb1,pdb2):
    top1 = md.load(pdb1)
    top2 = md.load(pdb2)
    top1_dm = md.compute_distances(top1, atom_pairs=pairs)
    top2_dm = md.compute_distances(top2, atom_pairs=pairs)

    return top1_dm,top2_dm


def top_CA_index(top):
    ca_index = {}
    top_content = open(top,'r').read()
    node_content = re.split('\[.+\]',top_content)[1:]
    node_name = re.findall('\[.+\]',top_content)
    top_content = dict(zip(node_name,node_content))
    atoms = top_content['[ atoms ]'].split('\n')
    print(len(atoms))
    for line in atoms:
        if not line.startswith(';'):
            temp = line.split()
            try:
                if temp[4] == 'CA':
                    ca_index_ = temp[5]
                    resi = temp[2]
                    res = temp[3]
                    ca_index['{}{}-CA'.format(res,resi)] = int(ca_index_) 
            except Exception as e:
                print(temp)

    return ca_index

def generate_cv(top_ca_index,top,pairs,top_dm,reference_top_dm,cv_name):
    #top1_dm 初始结构的距离
    #top2_dm 参考结构中的距离
    cv = 'CONTACTMAP ...\n'
    n = 1
    for i, v in enumerate(pairs):
        atom1 = top_ca_index[str(top.topology.atom(v[0]))]
        atom2 = top_ca_index[str(top.topology.atom(v[1]))]   

        d1 = top_dm[0][i]
        d2 = reference_top_dm[0][i]
        try:
            ref = (1.0-np.power(d2/min(d1,d2),6))/(1.0-np.power(d2/min(d1,d2),12))
        except:
            ref = 0.6
        if str(ref) == 'nan':
        	ref = 0.6
        cv +='ATOMS%d=%d,%d SWITCH%d={RATIONAL R_0=%.2f NN=6 MM=10} REFERENCE%d=%.4f\n' % (n, atom1,atom2, n, min(d1,d2), n,ref)
        n += 1
    cv += 'LABEL={}\n'.format(cv_name)
    cv += 'CMDIST\n'
    cv += '... CONTACTMAP\n'

    return cv

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-c",nargs='+',help = '两个结构的correlation.dat文件')
    parser.add_argument("-pdb",nargs='+',help = '两个结构的*.pdb文件')
    parser.add_argument("-top",help = 'md模拟体系建立过程中的topol.top文件')

    args = parser.parse_args()
    if len(args.c) == 2:
        corre1,corre2 = args.c
    else:
        raise ArgumentsError('-c 应输入两个相关性分析的数据文件，空格隔开')
    if len(args.pdb) == 2:
        pdb1,pdb2 = args.pdb
    else:
        raise ArgumentsError('-pdb 应输入两个pdb')
    top = args.top

    pairs = get_atom_pairs(corre1,corre2,pdb1)

    dm1,dm2 = compute_pairs_distance(pairs,pdb1,pdb2)

    top_ca_index = top_CA_index(top)

    cv1 = generate_cv(top_ca_index,md.load(pdb1),pairs,dm1,dm2,'cv1')

    cv2 = generate_cv(top_ca_index,md.load(pdb1),pairs,dm2,dm1,'cv2')

    wte = '\nwte: METAD ARG=cv1,cv2 PACE=500 HEIGHT=5 SIGMA=1.2,1.2 FILE=HILLS BIASFACTOR=16.0 TEMP=300\n\n'

    print_ = 'PRINT ARG=* STRIDE=100 FILE=COLVAR\n'

    result = cv1+'\n'+cv2 + wte + print_

    with open('plumed.dat','w') as f:
        f.write(result)
 
