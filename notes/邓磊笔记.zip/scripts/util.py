import mdtraj as md 
import numpy as np 
import os

def calc_distance():
    pass
def load_traj(traj_files, top, stride = 1, lazy_load = False, start = None, end= None):
    #读取轨迹文件

    traj = None
    temp_pdb = ''
    if not lazy_load:
        for t in traj_files:
            try:
                traj_ = md.load(t, top=top)[start:end:stride]
            except:
                top = pdb_CA(top)
                traj_ = md.load(t, top=top)[start:end:stride]
            try:
                traj.join(traj_)
            except AttributeError:
                traj = traj_
    else:
        for t in traj_files:
            try:
                iter_traj = md.iterload(t,top=top,chunk=500)
            except:
                top = pdb_CA(top)
                iter_traj = md.iterload(t,top=top,chunk=500)
            traj_ = iter_traj.next()
            for chunk in iter_traj:
                traj_ += chunk
            traj_ = traj_[start:end:stride]
            try:
                traj.join(traj_)
            except AttributeError:
                traj = traj_
    if isinstance(top,str):
        top_ = md.load(top)
    traj.superpose(reference=top_)
    if top == 'temp.pdb':
        os.remove('temp.pdb')
    return traj

def  pdb_CA(pdb):
    new_pdb = ''
    with open(pdb,'r') as f:
        for line in f:
            if line.startswith('ATOM') and line.split()[2] == 'CA':
                new_pdb += line
    with open('temp.pdb','w') as w:
        w.write(new_pdb)
    return 'temp.pdb'


class ArgumentsError(Exception):
    def __init__(self,ErrorInfo):
        super().__init__(self)
        self.errorinfo = ErrorInfo
    def __str__(self):
        return self.errorinfo

